SpecialCharacterRemover
-----------------------
-----------------------
version: 1.1.0

Author: Rishu Shrivastava

This is the version 1.1.0 of the Special Character Remover. Its a pentaho kettle step plugin.
This has been a extension of the prev. version with addition features of algorithm choice and also writing your own custom codes.

How to install this plugin?:
-----------------------------
Simply copy the contents of the folder into the "pentaho/design-tools/data-integration/plugins/steps/SpecialCharacterRemover". Note you need to create "SpecialCharacterRemover" folder first.

Start your pentaho DI

Open Transformation

Open "Experimental" tab. You will find a step named "Special Character Remover".

Simple :) Enjoy :) 